package ifpr.pgua.eic.exemplo;

public class Launcher {
    public static void main(String[] args) {
        App.launch(App.class, args);
    }
}
